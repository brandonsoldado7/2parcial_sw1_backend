import '../utils/json_utils.dart';


/// ==========================================================
/// 📄 Modelo generado automáticamente por CodeGenFlutterService
/// ==========================================================
class Colegio {
  // 🔹 Atributos propios
  int? id;
  String? nombre;
  String? direccion;
  String? telefono;

  // 🔹 Relaciones (solo ManyToOne / OneToOne)

  // 🔹 Constructor
  Colegio({
      this.id,
      this.nombre,
      this.direccion,
      this.telefono,
  })
  ;

    // 🔹 fromJson factory
    factory Colegio.fromJson(Map<String, dynamic> json) {
    return Colegio(
    id: autoConvert<int>(json['id']),
    nombre: autoConvert<String>(json['nombre']),
    direccion: autoConvert<String>(json['direccion']),
    telefono: autoConvert<String>(json['telefono']),
    );
    }

    // 🔹 toJson
    @override
    Map<String, dynamic> toJson() => {

      'id': id,
      'nombre': nombre,
      'direccion': direccion,
      'telefono': telefono,

    };


    // 🔹 toString (para vistas y Dropdowns)
    @override
    String toString() {
        return '${id ?? "s/d"}';
    }


}
