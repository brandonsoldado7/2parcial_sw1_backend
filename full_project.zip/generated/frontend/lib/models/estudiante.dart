import '../utils/json_utils.dart';

import 'inscripcion_curso.dart';

/// ==========================================================
/// 📄 Modelo generado automáticamente por CodeGenFlutterService
/// ==========================================================
class Estudiante {
  // 🔹 Atributos propios
  int? id;
  String? nombre;
  String? apellido;
  DateTime? fechaNacimiento;
  String? numeroMatricula;

  // 🔹 Relaciones (solo ManyToOne / OneToOne)
  InscripcionCurso? inscripcioncurso;

  // 🔹 Constructor
  Estudiante({
      this.id,
      this.nombre,
      this.apellido,
      this.fechaNacimiento,
      this.numeroMatricula,
    this.inscripcioncurso
  })
  ;

    // 🔹 fromJson factory
    factory Estudiante.fromJson(Map<String, dynamic> json) {
    return Estudiante(
    id: autoConvert<int>(json['id']),
    nombre: autoConvert<String>(json['nombre']),
    apellido: autoConvert<String>(json['apellido']),
    fechaNacimiento: autoConvert<DateTime>(json['fechaNacimiento']),
    numeroMatricula: autoConvert<String>(json['numeroMatricula']),
    inscripcioncurso:
      (json['inscripcioncurso'] is Map<String, dynamic>)
          ? InscripcionCurso.fromJson(json['inscripcioncurso'])
          : (json['inscripcioncurso'] != null
              ? InscripcionCurso(id: autoConvert<int>(json['inscripcioncurso']))
              : null)
    );
    }

    // 🔹 toJson
    @override
    Map<String, dynamic> toJson() => {

      'id': id,
      'nombre': nombre,
      'apellido': apellido,
      'fechaNacimiento': fechaNacimiento?.toIso8601String().split('T').first,
      'numeroMatricula': numeroMatricula,

      'inscripcioncurso': inscripcioncurso != null ? {'id': inscripcioncurso!.id} : null,
    };


    // 🔹 toString (para vistas y Dropdowns)
    @override
    String toString() {
        return '${id ?? "s/d"}';
    }


}
