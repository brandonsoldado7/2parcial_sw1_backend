import '../utils/json_utils.dart';

import 'inscripcion_curso.dart';

/// ==========================================================
/// 📄 Modelo generado automáticamente por CodeGenFlutterService
/// ==========================================================
class Curso {
  // 🔹 Atributos propios
  int? id;
  String? nombre;
  String? descripcion;
  int? anioAcademico;

  // 🔹 Relaciones (solo ManyToOne / OneToOne)
  InscripcionCurso? inscripcioncurso;

  // 🔹 Constructor
  Curso({
      this.id,
      this.nombre,
      this.descripcion,
      this.anioAcademico,
    this.inscripcioncurso
  })
  ;

    // 🔹 fromJson factory
    factory Curso.fromJson(Map<String, dynamic> json) {
    return Curso(
    id: autoConvert<int>(json['id']),
    nombre: autoConvert<String>(json['nombre']),
    descripcion: autoConvert<String>(json['descripcion']),
    anioAcademico: autoConvert<int>(json['anioAcademico']),
    inscripcioncurso:
      (json['inscripcioncurso'] is Map<String, dynamic>)
          ? InscripcionCurso.fromJson(json['inscripcioncurso'])
          : (json['inscripcioncurso'] != null
              ? InscripcionCurso(id: autoConvert<int>(json['inscripcioncurso']))
              : null)
    );
    }

    // 🔹 toJson
    @override
    Map<String, dynamic> toJson() => {

      'id': id,
      'nombre': nombre,
      'descripcion': descripcion,
      'anioAcademico': anioAcademico,

      'inscripcioncurso': inscripcioncurso != null ? {'id': inscripcioncurso!.id} : null,
    };


    // 🔹 toString (para vistas y Dropdowns)
    @override
    String toString() {
        return '${id ?? "s/d"}';
    }


}
