import '../utils/json_utils.dart';

import 'imparte.dart';

/// ==========================================================
/// 📄 Modelo generado automáticamente por CodeGenFlutterService
/// ==========================================================
class Profesor {
  // 🔹 Atributos propios
  int? id;
  String? nombre;
  String? apellido;
  String? especialidad;
  double? salario;

  // 🔹 Relaciones (solo ManyToOne / OneToOne)
  Imparte? imparte;

  // 🔹 Constructor
  Profesor({
      this.id,
      this.nombre,
      this.apellido,
      this.especialidad,
      this.salario,
    this.imparte
  })
  ;

    // 🔹 fromJson factory
    factory Profesor.fromJson(Map<String, dynamic> json) {
    return Profesor(
    id: autoConvert<int>(json['id']),
    nombre: autoConvert<String>(json['nombre']),
    apellido: autoConvert<String>(json['apellido']),
    especialidad: autoConvert<String>(json['especialidad']),
    salario: autoConvert<double>(json['salario']),
    imparte:
      (json['imparte'] is Map<String, dynamic>)
          ? Imparte.fromJson(json['imparte'])
          : (json['imparte'] != null
              ? Imparte(id: autoConvert<int>(json['imparte']))
              : null)
    );
    }

    // 🔹 toJson
    @override
    Map<String, dynamic> toJson() => {

      'id': id,
      'nombre': nombre,
      'apellido': apellido,
      'especialidad': especialidad,
      'salario': salario,

      'imparte': imparte != null ? {'id': imparte!.id} : null,
    };


    // 🔹 toString (para vistas y Dropdowns)
    @override
    String toString() {
        return '${id ?? "s/d"}';
    }


}
