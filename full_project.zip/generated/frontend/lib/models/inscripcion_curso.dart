import '../utils/json_utils.dart';

import 'estudiante.dart';
import 'curso.dart';

/// ==========================================================
/// 📄 Modelo generado automáticamente por CodeGenFlutterService
/// ==========================================================
class InscripcionCurso {
  // 🔹 Atributos propios
  int? id;
  DateTime? fechaInscripcion;
  double? calificacion;

  // 🔹 Relaciones (solo ManyToOne / OneToOne)
  Estudiante? estudiante;
  Curso? curso;

  // 🔹 Constructor
  InscripcionCurso({
      this.id,
      this.fechaInscripcion,
      this.calificacion,
    this.estudiante,
    this.curso
  })
  ;

    // 🔹 fromJson factory
    factory InscripcionCurso.fromJson(Map<String, dynamic> json) {
    return InscripcionCurso(
    id: autoConvert<int>(json['id']),
    fechaInscripcion: autoConvert<DateTime>(json['fechaInscripcion']),
    calificacion: autoConvert<double>(json['calificacion']),
    estudiante:
      (json['estudiante'] is Map<String, dynamic>)
          ? Estudiante.fromJson(json['estudiante'])
          : (json['estudiante'] != null
              ? Estudiante(id: autoConvert<int>(json['estudiante']))
              : null),
    curso:
      (json['curso'] is Map<String, dynamic>)
          ? Curso.fromJson(json['curso'])
          : (json['curso'] != null
              ? Curso(id: autoConvert<int>(json['curso']))
              : null)
    );
    }

    // 🔹 toJson
    @override
    Map<String, dynamic> toJson() => {

      'id': id,
      'fechaInscripcion': fechaInscripcion?.toIso8601String().split('T').first,
      'calificacion': calificacion,

      'estudiante': estudiante != null ? {'id': estudiante!.id} : null,
      'curso': curso != null ? {'id': curso!.id} : null,
    };


    // 🔹 toString (para vistas y Dropdowns)
    @override
    String toString() {
        return '${id ?? "s/d"}';
    }


}
