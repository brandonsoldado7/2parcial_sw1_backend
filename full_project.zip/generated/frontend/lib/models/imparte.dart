import '../utils/json_utils.dart';

import 'profesor.dart';
import 'asignatura.dart';

/// ==========================================================
/// 📄 Modelo generado automáticamente por CodeGenFlutterService
/// ==========================================================
class Imparte {
  // 🔹 Atributos propios
  int? id;
  DateTime? fechaInicio;
  DateTime? fechaFin;

  // 🔹 Relaciones (solo ManyToOne / OneToOne)
  Profesor? profesor;
  Asignatura? asignatura;

  // 🔹 Constructor
  Imparte({
      this.id,
      this.fechaInicio,
      this.fechaFin,
    this.profesor,
    this.asignatura
  })
  ;

    // 🔹 fromJson factory
    factory Imparte.fromJson(Map<String, dynamic> json) {
    return Imparte(
    id: autoConvert<int>(json['id']),
    fechaInicio: autoConvert<DateTime>(json['fechaInicio']),
    fechaFin: autoConvert<DateTime>(json['fechaFin']),
    profesor:
      (json['profesor'] is Map<String, dynamic>)
          ? Profesor.fromJson(json['profesor'])
          : (json['profesor'] != null
              ? Profesor(id: autoConvert<int>(json['profesor']))
              : null),
    asignatura:
      (json['asignatura'] is Map<String, dynamic>)
          ? Asignatura.fromJson(json['asignatura'])
          : (json['asignatura'] != null
              ? Asignatura(id: autoConvert<int>(json['asignatura']))
              : null)
    );
    }

    // 🔹 toJson
    @override
    Map<String, dynamic> toJson() => {

      'id': id,
      'fechaInicio': fechaInicio?.toIso8601String().split('T').first,
      'fechaFin': fechaFin?.toIso8601String().split('T').first,

      'profesor': profesor != null ? {'id': profesor!.id} : null,
      'asignatura': asignatura != null ? {'id': asignatura!.id} : null,
    };


    // 🔹 toString (para vistas y Dropdowns)
    @override
    String toString() {
        return '${id ?? "s/d"}';
    }


}
