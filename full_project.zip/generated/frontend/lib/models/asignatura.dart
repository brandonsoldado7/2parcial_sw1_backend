import '../utils/json_utils.dart';

import 'imparte.dart';

/// ==========================================================
/// 📄 Modelo generado automáticamente por CodeGenFlutterService
/// ==========================================================
class Asignatura {
  // 🔹 Atributos propios
  int? id;
  String? nombre;
  int? creditos;
  String? descripcion;

  // 🔹 Relaciones (solo ManyToOne / OneToOne)
  Imparte? imparte;

  // 🔹 Constructor
  Asignatura({
      this.id,
      this.nombre,
      this.creditos,
      this.descripcion,
    this.imparte
  })
  ;

    // 🔹 fromJson factory
    factory Asignatura.fromJson(Map<String, dynamic> json) {
    return Asignatura(
    id: autoConvert<int>(json['id']),
    nombre: autoConvert<String>(json['nombre']),
    creditos: autoConvert<int>(json['creditos']),
    descripcion: autoConvert<String>(json['descripcion']),
    imparte:
      (json['imparte'] is Map<String, dynamic>)
          ? Imparte.fromJson(json['imparte'])
          : (json['imparte'] != null
              ? Imparte(id: autoConvert<int>(json['imparte']))
              : null)
    );
    }

    // 🔹 toJson
    @override
    Map<String, dynamic> toJson() => {

      'id': id,
      'nombre': nombre,
      'creditos': creditos,
      'descripcion': descripcion,

      'imparte': imparte != null ? {'id': imparte!.id} : null,
    };


    // 🔹 toString (para vistas y Dropdowns)
    @override
    String toString() {
        return '${id ?? "s/d"}';
    }


}
