import '../models/imparte.dart';
import '../utils/api_client.dart';

class ImparteService {
  final _api = ApiClient();
  final _endpoint = 'imparte';

  /// 🔹 Obtener todos los registros
  Future<List<Imparte>> getAll() async {
    final data = await _api.getList(_endpoint);
    return data.map<Imparte>((e) => Imparte.fromJson(e)).toList();
  }

  /// 🔹 Obtener registro por ID
  Future<Imparte> getById(int id) async {
    final data = await _api.getById(_endpoint, id);
    return Imparte.fromJson(data);
  }

  /// 🔹 Crear nuevo registro
  Future<void> create(Imparte item) async {
    await _api.create(_endpoint, item.toJson());
  }

  /// 🔹 Actualizar registro existente
  Future<void> update(int id, Imparte item) async {
    await _api.update(_endpoint, id, item.toJson());
  }

  /// 🔹 Eliminar registro
  Future<void> delete(int id) async {
    await _api.delete(_endpoint, id);
  }
}
