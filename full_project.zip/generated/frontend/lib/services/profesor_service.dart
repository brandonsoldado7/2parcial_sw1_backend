import '../models/profesor.dart';
import '../utils/api_client.dart';

class ProfesorService {
  final _api = ApiClient();
  final _endpoint = 'profesor';

  /// 🔹 Obtener todos los registros
  Future<List<Profesor>> getAll() async {
    final data = await _api.getList(_endpoint);
    return data.map<Profesor>((e) => Profesor.fromJson(e)).toList();
  }

  /// 🔹 Obtener registro por ID
  Future<Profesor> getById(int id) async {
    final data = await _api.getById(_endpoint, id);
    return Profesor.fromJson(data);
  }

  /// 🔹 Crear nuevo registro
  Future<void> create(Profesor item) async {
    await _api.create(_endpoint, item.toJson());
  }

  /// 🔹 Actualizar registro existente
  Future<void> update(int id, Profesor item) async {
    await _api.update(_endpoint, id, item.toJson());
  }

  /// 🔹 Eliminar registro
  Future<void> delete(int id) async {
    await _api.delete(_endpoint, id);
  }
}
