import '../models/estudiante.dart';
import '../utils/api_client.dart';

class EstudianteService {
  final _api = ApiClient();
  final _endpoint = 'estudiante';

  /// 🔹 Obtener todos los registros
  Future<List<Estudiante>> getAll() async {
    final data = await _api.getList(_endpoint);
    return data.map<Estudiante>((e) => Estudiante.fromJson(e)).toList();
  }

  /// 🔹 Obtener registro por ID
  Future<Estudiante> getById(int id) async {
    final data = await _api.getById(_endpoint, id);
    return Estudiante.fromJson(data);
  }

  /// 🔹 Crear nuevo registro
  Future<void> create(Estudiante item) async {
    await _api.create(_endpoint, item.toJson());
  }

  /// 🔹 Actualizar registro existente
  Future<void> update(int id, Estudiante item) async {
    await _api.update(_endpoint, id, item.toJson());
  }

  /// 🔹 Eliminar registro
  Future<void> delete(int id) async {
    await _api.delete(_endpoint, id);
  }
}
