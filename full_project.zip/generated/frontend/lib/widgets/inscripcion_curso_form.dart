import 'package:flutter/material.dart';
import '../models/inscripcion_curso.dart';
import '../models/estudiante.dart';
import '../services/estudiante_service.dart';
import '../models/curso.dart';
import '../services/curso_service.dart';

class InscripcionCursoForm extends StatefulWidget {
  final void Function(InscripcionCurso) onSaved;
  final InscripcionCurso? initialData; // para editar

  const InscripcionCursoForm({super.key, required this.onSaved, this.initialData});

  @override
  State<InscripcionCursoForm> createState() => _InscripcionCursoFormState();
}

class _InscripcionCursoFormState extends State<InscripcionCursoForm> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _data = {};

  int? _selectedEstudianteId;
  List<Estudiante> _estudianteList = [];
  final _estudianteService = EstudianteService();
  int? _selectedCursoId;
  List<Curso> _cursoList = [];
  final _cursoService = CursoService();


  @override
  void initState() {
    super.initState();

    // 🔹 Precargar datos si es edición
    if (widget.initialData != null) {
      final json = widget.initialData!.toJson();
      _data.addAll(json);

    }

    // 🔹 Cargar listas de relaciones ManyToOne
    _loadEstudianteList();
    _loadCursoList();
  }

  Future<void> _loadEstudianteList() async {
    final data = await _estudianteService.getAll();
    setState(() => _estudianteList = data);
  }
  Future<void> _loadCursoList() async {
    final data = await _cursoService.getAll();
    setState(() => _cursoList = data);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.initialData == null
          ? 'Nuevo InscripcionCurso'
          : 'Editar InscripcionCurso'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

                  TextFormField(
                    initialValue: widget.initialData?.fechaInscripcion?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'fechaInscripcion',
                        hintText: 'Formato: yyyy-MM-dd',
                    ),
                    onSaved: (val) => _data['fechaInscripcion'] = val,
                      keyboardType: TextInputType.text,
                  ),
                  TextFormField(
                    initialValue: widget.initialData?.calificacion?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'calificacion',
                        hintText: 'Ingrese un número decimal',
                    ),
                    onSaved: (val) => _data['calificacion'] = val,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  ),
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                value: _selectedEstudianteId,
                decoration: InputDecoration(labelText: 'Estudiante'),
                items: _estudianteList.map((e) {
                  return DropdownMenuItem<int>(
                    value: e.id,
                    child: Text(e.toString()),
                  );
                }).toList(),
                onChanged: (val) => setState(() => _selectedEstudianteId = val),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                value: _selectedCursoId,
                decoration: InputDecoration(labelText: 'Curso'),
                items: _cursoList.map((e) {
                  return DropdownMenuItem<int>(
                    value: e.id,
                    child: Text(e.toString()),
                  );
                }).toList(),
                onChanged: (val) => setState(() => _selectedCursoId = val),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            _formKey.currentState?.save();

            // 🔹 Guardar booleanos

            // 🔹 Guardar relaciones (ManyToOne)
            if (_selectedEstudianteId != null) {
              _data['estudiante'] = {'id': _selectedEstudianteId};
            }
            if (_selectedCursoId != null) {
              _data['curso'] = {'id': _selectedCursoId};
            }

            widget.onSaved(InscripcionCurso.fromJson(_data));
            Navigator.pop(context);
          },
          child: const Text('Guardar'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
      ],
    );
  }
}
