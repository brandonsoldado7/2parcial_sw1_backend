import 'package:flutter/material.dart';
import '../models/asignatura.dart';
import '../models/curso.dart';
import '../services/curso_service.dart';
import '../models/imparte.dart';
import '../services/imparte_service.dart';

class AsignaturaForm extends StatefulWidget {
  final void Function(Asignatura) onSaved;
  final Asignatura? initialData; // para editar

  const AsignaturaForm({super.key, required this.onSaved, this.initialData});

  @override
  State<AsignaturaForm> createState() => _AsignaturaFormState();
}

class _AsignaturaFormState extends State<AsignaturaForm> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _data = {};

  int? _selectedImparteId;
  List<Imparte> _imparteList = [];
  final _imparteService = ImparteService();


  @override
  void initState() {
    super.initState();

    // 🔹 Precargar datos si es edición
    if (widget.initialData != null) {
      final json = widget.initialData!.toJson();
      _data.addAll(json);

    }

    // 🔹 Cargar listas de relaciones ManyToOne
    _loadImparteList();
  }

  Future<void> _loadImparteList() async {
    final data = await _imparteService.getAll();
    setState(() => _imparteList = data);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.initialData == null
          ? 'Nuevo Asignatura'
          : 'Editar Asignatura'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

                  TextFormField(
                    initialValue: widget.initialData?.nombre?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'nombre',
                        hintText: 'Ingrese texto (String)',
                    ),
                    onSaved: (val) => _data['nombre'] = val,
                      keyboardType: TextInputType.text,
                  ),
                  TextFormField(
                    initialValue: widget.initialData?.creditos?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'creditos',
                        hintText: 'Ingrese un número entero',
                    ),
                    onSaved: (val) => _data['creditos'] = val,
                      keyboardType: TextInputType.number,
                  ),
                  TextFormField(
                    initialValue: widget.initialData?.descripcion?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'descripcion',
                        hintText: 'Ingrese texto (String)',
                    ),
                    onSaved: (val) => _data['descripcion'] = val,
                      keyboardType: TextInputType.text,
                  ),
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                value: _selectedImparteId,
                decoration: InputDecoration(labelText: 'Imparte'),
                items: _imparteList.map((e) {
                  return DropdownMenuItem<int>(
                    value: e.id,
                    child: Text(e.toString()),
                  );
                }).toList(),
                onChanged: (val) => setState(() => _selectedImparteId = val),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            _formKey.currentState?.save();

            // 🔹 Guardar booleanos

            // 🔹 Guardar relaciones (ManyToOne)
            if (_selectedImparteId != null) {
              _data['imparte'] = {'id': _selectedImparteId};
            }

            widget.onSaved(Asignatura.fromJson(_data));
            Navigator.pop(context);
          },
          child: const Text('Guardar'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
      ],
    );
  }
}
