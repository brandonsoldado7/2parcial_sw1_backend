import 'package:flutter/material.dart';
import '../models/colegio.dart';
import '../models/estudiante.dart';
import '../services/estudiante_service.dart';
import '../models/profesor.dart';
import '../services/profesor_service.dart';
import '../models/curso.dart';
import '../services/curso_service.dart';

class ColegioForm extends StatefulWidget {
  final void Function(Colegio) onSaved;
  final Colegio? initialData; // para editar

  const ColegioForm({super.key, required this.onSaved, this.initialData});

  @override
  State<ColegioForm> createState() => _ColegioFormState();
}

class _ColegioFormState extends State<ColegioForm> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _data = {};



  @override
  void initState() {
    super.initState();

    // 🔹 Precargar datos si es edición
    if (widget.initialData != null) {
      final json = widget.initialData!.toJson();
      _data.addAll(json);

    }

    // 🔹 Cargar listas de relaciones ManyToOne
  }


  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.initialData == null
          ? 'Nuevo Colegio'
          : 'Editar Colegio'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

                  TextFormField(
                    initialValue: widget.initialData?.nombre?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'nombre',
                        hintText: 'Ingrese texto (String)',
                    ),
                    onSaved: (val) => _data['nombre'] = val,
                      keyboardType: TextInputType.text,
                  ),
                  TextFormField(
                    initialValue: widget.initialData?.direccion?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'direccion',
                        hintText: 'Ingrese texto (String)',
                    ),
                    onSaved: (val) => _data['direccion'] = val,
                      keyboardType: TextInputType.text,
                  ),
                  TextFormField(
                    initialValue: widget.initialData?.telefono?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'telefono',
                        hintText: 'Ingrese texto (String)',
                    ),
                    onSaved: (val) => _data['telefono'] = val,
                      keyboardType: TextInputType.text,
                  ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            _formKey.currentState?.save();

            // 🔹 Guardar booleanos

            // 🔹 Guardar relaciones (ManyToOne)

            widget.onSaved(Colegio.fromJson(_data));
            Navigator.pop(context);
          },
          child: const Text('Guardar'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
      ],
    );
  }
}
