import 'package:flutter/material.dart';
import '../models/imparte.dart';
import '../models/profesor.dart';
import '../services/profesor_service.dart';
import '../models/asignatura.dart';
import '../services/asignatura_service.dart';

class ImparteForm extends StatefulWidget {
  final void Function(Imparte) onSaved;
  final Imparte? initialData; // para editar

  const ImparteForm({super.key, required this.onSaved, this.initialData});

  @override
  State<ImparteForm> createState() => _ImparteFormState();
}

class _ImparteFormState extends State<ImparteForm> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _data = {};

  int? _selectedProfesorId;
  List<Profesor> _profesorList = [];
  final _profesorService = ProfesorService();
  int? _selectedAsignaturaId;
  List<Asignatura> _asignaturaList = [];
  final _asignaturaService = AsignaturaService();


  @override
  void initState() {
    super.initState();

    // 🔹 Precargar datos si es edición
    if (widget.initialData != null) {
      final json = widget.initialData!.toJson();
      _data.addAll(json);

    }

    // 🔹 Cargar listas de relaciones ManyToOne
    _loadProfesorList();
    _loadAsignaturaList();
  }

  Future<void> _loadProfesorList() async {
    final data = await _profesorService.getAll();
    setState(() => _profesorList = data);
  }
  Future<void> _loadAsignaturaList() async {
    final data = await _asignaturaService.getAll();
    setState(() => _asignaturaList = data);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.initialData == null
          ? 'Nuevo Imparte'
          : 'Editar Imparte'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

                  TextFormField(
                    initialValue: widget.initialData?.fechaInicio?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'fechaInicio',
                        hintText: 'Formato: yyyy-MM-dd',
                    ),
                    onSaved: (val) => _data['fechaInicio'] = val,
                      keyboardType: TextInputType.text,
                  ),
                  TextFormField(
                    initialValue: widget.initialData?.fechaFin?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'fechaFin',
                        hintText: 'Formato: yyyy-MM-dd',
                    ),
                    onSaved: (val) => _data['fechaFin'] = val,
                      keyboardType: TextInputType.text,
                  ),
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                value: _selectedProfesorId,
                decoration: InputDecoration(labelText: 'Profesor'),
                items: _profesorList.map((e) {
                  return DropdownMenuItem<int>(
                    value: e.id,
                    child: Text(e.toString()),
                  );
                }).toList(),
                onChanged: (val) => setState(() => _selectedProfesorId = val),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                value: _selectedAsignaturaId,
                decoration: InputDecoration(labelText: 'Asignatura'),
                items: _asignaturaList.map((e) {
                  return DropdownMenuItem<int>(
                    value: e.id,
                    child: Text(e.toString()),
                  );
                }).toList(),
                onChanged: (val) => setState(() => _selectedAsignaturaId = val),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            _formKey.currentState?.save();

            // 🔹 Guardar booleanos

            // 🔹 Guardar relaciones (ManyToOne)
            if (_selectedProfesorId != null) {
              _data['profesor'] = {'id': _selectedProfesorId};
            }
            if (_selectedAsignaturaId != null) {
              _data['asignatura'] = {'id': _selectedAsignaturaId};
            }

            widget.onSaved(Imparte.fromJson(_data));
            Navigator.pop(context);
          },
          child: const Text('Guardar'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
      ],
    );
  }
}
