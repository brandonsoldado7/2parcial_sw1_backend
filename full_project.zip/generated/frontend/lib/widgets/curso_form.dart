import 'package:flutter/material.dart';
import '../models/curso.dart';
import '../models/colegio.dart';
import '../services/colegio_service.dart';
import '../models/asignatura.dart';
import '../services/asignatura_service.dart';
import '../models/inscripcion_curso.dart';
import '../services/inscripcion_curso_service.dart';

class CursoForm extends StatefulWidget {
  final void Function(Curso) onSaved;
  final Curso? initialData; // para editar

  const CursoForm({super.key, required this.onSaved, this.initialData});

  @override
  State<CursoForm> createState() => _CursoFormState();
}

class _CursoFormState extends State<CursoForm> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _data = {};

  int? _selectedInscripcionCursoId;
  List<InscripcionCurso> _inscripcioncursoList = [];
  final _inscripcioncursoService = InscripcionCursoService();


  @override
  void initState() {
    super.initState();

    // 🔹 Precargar datos si es edición
    if (widget.initialData != null) {
      final json = widget.initialData!.toJson();
      _data.addAll(json);

    }

    // 🔹 Cargar listas de relaciones ManyToOne
    _loadInscripcionCursoList();
  }

  Future<void> _loadInscripcionCursoList() async {
    final data = await _inscripcioncursoService.getAll();
    setState(() => _inscripcioncursoList = data);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.initialData == null
          ? 'Nuevo Curso'
          : 'Editar Curso'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

                  TextFormField(
                    initialValue: widget.initialData?.nombre?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'nombre',
                        hintText: 'Ingrese texto (String)',
                    ),
                    onSaved: (val) => _data['nombre'] = val,
                      keyboardType: TextInputType.text,
                  ),
                  TextFormField(
                    initialValue: widget.initialData?.descripcion?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'descripcion',
                        hintText: 'Ingrese texto (String)',
                    ),
                    onSaved: (val) => _data['descripcion'] = val,
                      keyboardType: TextInputType.text,
                  ),
                  TextFormField(
                    initialValue: widget.initialData?.anioAcademico?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'anioAcademico',
                        hintText: 'Ingrese un número entero',
                    ),
                    onSaved: (val) => _data['anioAcademico'] = val,
                      keyboardType: TextInputType.number,
                  ),
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                value: _selectedInscripcionCursoId,
                decoration: InputDecoration(labelText: 'InscripcionCurso'),
                items: _inscripcioncursoList.map((e) {
                  return DropdownMenuItem<int>(
                    value: e.id,
                    child: Text(e.toString()),
                  );
                }).toList(),
                onChanged: (val) => setState(() => _selectedInscripcionCursoId = val),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            _formKey.currentState?.save();

            // 🔹 Guardar booleanos

            // 🔹 Guardar relaciones (ManyToOne)
            if (_selectedInscripcionCursoId != null) {
              _data['inscripcioncurso'] = {'id': _selectedInscripcionCursoId};
            }

            widget.onSaved(Curso.fromJson(_data));
            Navigator.pop(context);
          },
          child: const Text('Guardar'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
      ],
    );
  }
}
