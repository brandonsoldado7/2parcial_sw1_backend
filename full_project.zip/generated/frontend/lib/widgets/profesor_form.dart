import 'package:flutter/material.dart';
import '../models/profesor.dart';
import '../models/colegio.dart';
import '../services/colegio_service.dart';
import '../models/imparte.dart';
import '../services/imparte_service.dart';

class ProfesorForm extends StatefulWidget {
  final void Function(Profesor) onSaved;
  final Profesor? initialData; // para editar

  const ProfesorForm({super.key, required this.onSaved, this.initialData});

  @override
  State<ProfesorForm> createState() => _ProfesorFormState();
}

class _ProfesorFormState extends State<ProfesorForm> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _data = {};

  int? _selectedImparteId;
  List<Imparte> _imparteList = [];
  final _imparteService = ImparteService();


  @override
  void initState() {
    super.initState();

    // 🔹 Precargar datos si es edición
    if (widget.initialData != null) {
      final json = widget.initialData!.toJson();
      _data.addAll(json);

    }

    // 🔹 Cargar listas de relaciones ManyToOne
    _loadImparteList();
  }

  Future<void> _loadImparteList() async {
    final data = await _imparteService.getAll();
    setState(() => _imparteList = data);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.initialData == null
          ? 'Nuevo Profesor'
          : 'Editar Profesor'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

                  TextFormField(
                    initialValue: widget.initialData?.nombre?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'nombre',
                        hintText: 'Ingrese texto (String)',
                    ),
                    onSaved: (val) => _data['nombre'] = val,
                      keyboardType: TextInputType.text,
                  ),
                  TextFormField(
                    initialValue: widget.initialData?.apellido?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'apellido',
                        hintText: 'Ingrese texto (String)',
                    ),
                    onSaved: (val) => _data['apellido'] = val,
                      keyboardType: TextInputType.text,
                  ),
                  TextFormField(
                    initialValue: widget.initialData?.especialidad?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'especialidad',
                        hintText: 'Ingrese texto (String)',
                    ),
                    onSaved: (val) => _data['especialidad'] = val,
                      keyboardType: TextInputType.text,
                  ),
                  TextFormField(
                    initialValue: widget.initialData?.salario?.toString() ?? '',
                    decoration: InputDecoration(
                      labelText: 'salario',
                        hintText: 'Ingrese un número decimal',
                    ),
                    onSaved: (val) => _data['salario'] = val,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  ),
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                value: _selectedImparteId,
                decoration: InputDecoration(labelText: 'Imparte'),
                items: _imparteList.map((e) {
                  return DropdownMenuItem<int>(
                    value: e.id,
                    child: Text(e.toString()),
                  );
                }).toList(),
                onChanged: (val) => setState(() => _selectedImparteId = val),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            _formKey.currentState?.save();

            // 🔹 Guardar booleanos

            // 🔹 Guardar relaciones (ManyToOne)
            if (_selectedImparteId != null) {
              _data['imparte'] = {'id': _selectedImparteId};
            }

            widget.onSaved(Profesor.fromJson(_data));
            Navigator.pop(context);
          },
          child: const Text('Guardar'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
      ],
    );
  }
}
