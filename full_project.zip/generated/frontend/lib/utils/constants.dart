class Constants {
  static const String baseUrl = "http://192.168.0.76:8081/api";
}
