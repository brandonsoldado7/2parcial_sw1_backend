INSERT INTO colegio (id, nombre, direccion, telefono) VALUES
(1, 'Colegio San Juan', 'Calle Falsa 123', '555-1234'),
(2, 'Instituto La Paz', 'Avenida Siempre Viva 742', '555-5678'),
(3, 'Academia Libertad', 'Boulevard Central 45', '555-8765'),
(4, 'Centro Educativo Los Andes', 'Plaza Mayor 8', '555-4321');

INSERT INTO estudiante (id, nombre, apellido, fecha_nacimiento, numero_matricula, colegio_id) VALUES
(1, 'Luis', 'Martinez', '2005-03-15', 'MAT2023001', 1),
(2, 'Ana', 'Gomez', '2006-07-22', 'MAT2023002', 1),
(3, 'Carlos', 'Fernandez', '2005-11-30', 'MAT2023003', 2),
(4, 'Maria', 'Rodriguez', '2006-01-10', 'MAT2023004', 3);

INSERT INTO profesor (id, nombre, apellido, especialidad, salario, colegio_id) VALUES
(1, 'Jose', 'Lopez', 'Matematicas', 1500.50, 1),
(2, 'Elena', 'Morales', 'Historia', 1400.00, 1),
(3, 'Ricardo', 'Sanchez', 'Biologia', 1550.75, 2),
(4, 'Sofia', 'Diaz', 'Quimica', 1480.25, 3);

INSERT INTO curso (id, nombre, descripcion, anio_academico, colegio_id) VALUES
(1, 'Matematica Avanzada', 'Curso de matematica nivel avanzado', 2023, 1),
(2, 'Historia Universal', 'Estudio de la historia mundial', 2023, 1),
(3, 'Biologia General', 'Fundamentos de biologia', 2023, 2),
(4, 'Quimica Organica', 'Introduccion a la quimica organica', 2023, 3);

INSERT INTO asignatura (id, nombre, creditos, descripcion, curso_id) VALUES
(1, 'Algebra', 4, 'Estudio de algebra y ecuaciones', 1),
(2, 'Historia Medieval', 3, 'Analisis de la historia medieval', 2),
(3, 'Ecologia', 4, 'Conceptos de ecologia y medio ambiente', 3),
(4, 'Reaccion Quimica', 3, 'Principios basicos de reaccion quimica', 4);

INSERT INTO imparte (id, fecha_inicio, fecha_fin, profesor_id, asignatura_id) VALUES
(1, '2023-01-10', '2023-06-10', 1, 1),
(2, '2023-01-15', '2023-06-15', 2, 2),
(3, '2023-02-01', '2023-07-01', 3, 3),
(4, '2023-02-10', '2023-07-10', 4, 4);

INSERT INTO inscripcion_curso (id, fecha_inscripcion, calificacion, estudiante_id, curso_id) VALUES
(1, '2023-01-05', 8.5, 1, 1),
(2, '2023-01-06', 9.0, 2, 2),
(3, '2023-01-10', 7.5, 3, 3),
(4, '2023-01-12', 8.0, 4, 4);