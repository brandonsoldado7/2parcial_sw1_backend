package com.example.demo.service;

import com.example.demo.model.Colegio;
import com.example.demo.repository.ColegioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

/**
 * Servicio generado automáticamente para la entidad Colegio.
 * Proporciona operaciones CRUD básicas y puede ampliarse con lógica personalizada.
 */
@Service
public class ColegioService {

    @Autowired
    private ColegioRepository repository;

    // CREATE o UPDATE
    public Colegio save(Colegio entity) {
        return repository.save(entity);
    }

    // READ ALL
    public List<Colegio> findAll() {
        return repository.findAll();
    }

    // READ BY ID
    public Optional<Colegio> findById(Long id) {
        try {
            return repository.findById(id);
        } catch (Exception e) {
            System.err.println("⚠️ Error buscando Colegio por ID: " + e.getMessage());
            return Optional.empty();
        }
    }

    // DELETE
    public boolean delete(Long id) {
        try {
            if (repository.existsById(id)) {
                repository.deleteById(id);
                return true;
            }
            return false;
        } catch (Exception e) {
            System.err.println("⚠️ Error eliminando Colegio con ID " + id + ": " + e.getMessage());
            return false;
        }
    }
}
