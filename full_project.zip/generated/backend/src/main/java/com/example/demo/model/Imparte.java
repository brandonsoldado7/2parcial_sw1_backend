package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.*;
import java.time.*;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Data
@Entity
@JsonIdentityInfo(
    generator = ObjectIdGenerators.PropertyGenerator.class,
    property = "id"
)

public class Imparte {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Date fechaInicio;
    private Date fechaFin;









    
    @ManyToOne
    @JoinColumn(name = "profesor_id", referencedColumnName = "id")
    private Profesor profesor;








    
    @ManyToOne
    @JoinColumn(name = "asignatura_id", referencedColumnName = "id")
    private Asignatura asignatura;

}
