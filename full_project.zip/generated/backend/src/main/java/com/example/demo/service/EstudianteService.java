package com.example.demo.service;

import com.example.demo.model.Estudiante;
import com.example.demo.repository.EstudianteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

/**
 * Servicio generado automáticamente para la entidad Estudiante.
 * Proporciona operaciones CRUD básicas y puede ampliarse con lógica personalizada.
 */
@Service
public class EstudianteService {

    @Autowired
    private EstudianteRepository repository;

    // CREATE o UPDATE
    public Estudiante save(Estudiante entity) {
        return repository.save(entity);
    }

    // READ ALL
    public List<Estudiante> findAll() {
        return repository.findAll();
    }

    // READ BY ID
    public Optional<Estudiante> findById(Long id) {
        try {
            return repository.findById(id);
        } catch (Exception e) {
            System.err.println("⚠️ Error buscando Estudiante por ID: " + e.getMessage());
            return Optional.empty();
        }
    }

    // DELETE
    public boolean delete(Long id) {
        try {
            if (repository.existsById(id)) {
                repository.deleteById(id);
                return true;
            }
            return false;
        } catch (Exception e) {
            System.err.println("⚠️ Error eliminando Estudiante con ID " + id + ": " + e.getMessage());
            return false;
        }
    }
}
