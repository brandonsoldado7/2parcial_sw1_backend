package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.*;
import java.time.*;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Data
@Entity
@JsonIdentityInfo(
    generator = ObjectIdGenerators.PropertyGenerator.class,
    property = "id"
)

public class Colegio {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String direccion;
    private String telefono;









    
    @OneToMany(mappedBy = "colegio")
    private List<Estudiante> estudiantes;








    
    @OneToMany(mappedBy = "colegio")
    private List<Profesor> profesors;








    
    @OneToMany(mappedBy = "colegio")
    private List<Curso> cursos;

}
