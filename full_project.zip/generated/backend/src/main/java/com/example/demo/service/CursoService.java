package com.example.demo.service;

import com.example.demo.model.Curso;
import com.example.demo.repository.CursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

/**
 * Servicio generado automáticamente para la entidad Curso.
 * Proporciona operaciones CRUD básicas y puede ampliarse con lógica personalizada.
 */
@Service
public class CursoService {

    @Autowired
    private CursoRepository repository;

    // CREATE o UPDATE
    public Curso save(Curso entity) {
        return repository.save(entity);
    }

    // READ ALL
    public List<Curso> findAll() {
        return repository.findAll();
    }

    // READ BY ID
    public Optional<Curso> findById(Long id) {
        try {
            return repository.findById(id);
        } catch (Exception e) {
            System.err.println("⚠️ Error buscando Curso por ID: " + e.getMessage());
            return Optional.empty();
        }
    }

    // DELETE
    public boolean delete(Long id) {
        try {
            if (repository.existsById(id)) {
                repository.deleteById(id);
                return true;
            }
            return false;
        } catch (Exception e) {
            System.err.println("⚠️ Error eliminando Curso con ID " + id + ": " + e.getMessage());
            return false;
        }
    }
}
