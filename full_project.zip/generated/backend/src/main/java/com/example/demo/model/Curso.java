package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.*;
import java.time.*;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Data
@Entity
@JsonIdentityInfo(
    generator = ObjectIdGenerators.PropertyGenerator.class,
    property = "id"
)

public class Curso {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String descripcion;
    private int anioAcademico;









    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "colegio_id", referencedColumnName = "id")
    private Colegio colegio;








    
    @OneToMany(mappedBy = "curso")
    private List<Asignatura> asignaturas;








    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "inscripcionCurso_id", referencedColumnName = "id")
    private InscripcionCurso inscripcionCurso;

}
