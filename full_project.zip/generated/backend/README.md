# 🧠 Backend generado automáticamente 🚀

**Paquete base:** `com.example.demo`
**Fecha de generación:** 2025-11-11 23:16:32

---

## 📦 Entidades generadas:
- **Colegio**
    (hereda de null)
- **Estudiante**
    (hereda de null)
- **Profesor**
    (hereda de null)
- **Curso**
    (hereda de null)
- **Asignatura**
    (hereda de null)
- **Imparte**
    (hereda de null)
- **InscripcionCurso**
    (hereda de null)

---

## 🔁 Endpoints CRUD comunes:

| Método | Ruta | Descripción |
|--------|------|--------------|
| **GET** | `/api/{entidad}/listar` | Listar todos los registros |
| **GET** | `/api/{entidad}/{id}` | Obtener un registro por ID |
| **POST** | `/api/{entidad}/guardar` | Crear un nuevo registro |
| **PUT** | `/api/{entidad}/actualizar/{id}` | Actualizar un registro existente |
| **DELETE** | `/api/{entidad}/eliminar/{id}` | Eliminar un registro |

---

> ⚙️ Generado automáticamente mediante **CodeGenService (IA + FreeMarker)**
> Proyecto autogenerado basado en modelo JSON enriquecido 🧩
